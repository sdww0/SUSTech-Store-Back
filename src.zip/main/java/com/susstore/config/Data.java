package com.susstore.config;

public class Data {

    public static final String USER_UPLOAD_PATH = "D:/ooad/store/upload/user/";

}
