package com.susstore.pojo;

public class Comment {

    private String content;
    private String username;
    private Integer userId;
    private String picturePath;


}
